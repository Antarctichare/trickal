// 트릭컬노트 카드/사도 연동기 - 페이지(MAIN) 컨텍스트 스크립트
// 하는 일: 이 페이지가 "이미 받은" 응답 중 카드 레벨과 사도 레벨 정보만 골라 확장 프로그램 브릿지에 넘긴다.
// 하지 않는 일: 별도 네트워크 요청 없음 / 서버 전송 없음 / 쿠키·토큰·프로필(닉네임, 유저ID, 친구코드) 수집 없음.
(function () {
  "use strict";

  const DEBUG = false; // 문제 확인용. 배포 시 false 유지

  const origParse = JSON.parse;
  const QUICK_RE = /"(cardId|apostleId)"\s*:/;

  // 응답 구조:
  //   user.data.card.cards       = [{ cardId, type, level, count, limitBreak }, ...]
  //   user.data.apostle.apostles = [{ apostleId, level, rank, grade, asideGrade, ... }, ...]
  function findArrays(node, out, depth) {
    if (!node || typeof node !== "object" || Array.isArray(node) || depth > 5) return;
    for (const k of Object.keys(node)) {
      const v = node[k];
      if (k === "cards" && Array.isArray(v)) out.cards = v;
      else if (k === "apostles" && Array.isArray(v)) out.apostles = v;
      else if (k === "user" || k === "data" || k === "card" || k === "apostle") findArrays(v, out, depth + 1);
    }
  }

  const num = (x, d = 0) => (Number.isFinite(Number(x)) ? Number(x) : d);

  // 필요한 필드만 복사한다. (profile, skinId, boardSteps 등은 수집하지 않음)
  function extractPureSpec(root) {
    const found = {};
    findArrays(root, found, 0);

    const cards = {};
    const cardsDetail = {};
    const apostles = {};

    for (const c of found.cards || []) {
      const id = Number(c && c.cardId);
      const lv = Number(c && c.level);
      if (!Number.isInteger(id) || !(lv > 0)) continue;
      cards[id] = lv;
      cardsDetail[id] = { level: lv, count: num(c.count), limitBreak: num(c.limitBreak), type: num(c.type) };
    }

    for (const a of found.apostles || []) {
      const id = Number(a && a.apostleId);
      if (!Number.isInteger(id)) continue;
      apostles[id] = {
        level: num(a.level, 1),
        rank: num(a.rank),
        grade: num(a.grade),
        asideGrade: num(a.asideGrade),
        activeSkillLevel: num(a.activeSkillLevel, 1),
        ultimateSkillLevel: num(a.ultimateSkillLevel, 1),
        asideLevelLimitBreak: num(a.asideLevelLimitBreak),
      };
    }

    return { cards, cardsDetail, apostles, countC: Object.keys(cards).length, countA: Object.keys(apostles).length };
  }

  // URL의 쿼리스트링에 토큰이 있을 수 있으므로 origin + path 만 남긴다.
  function safeUrl(u) {
    try {
      const x = new URL(u, location.href);
      return x.origin + x.pathname;
    } catch (e) {
      return "";
    }
  }

  let lastSig = "";
  function emit(res, url) {
    if (res.countC === 0 && res.countA === 0) return;
    const sig = res.countC + ":" + res.countA + ":" + Object.values(res.cards).reduce((s, v) => s + v, 0);
    if (sig === lastSig) return;
    lastSig = sig;
    if (DEBUG) console.log("[트릭컬 연동기] 카드", res.countC, "/ 사도", res.countA);
    window.postMessage(
      {
        type: "TRICKCAL_SPEC_CAPTURED",
        payload: { cards: res.cards, cardsDetail: res.cardsDetail, apostles: res.apostles, sourceUrl: safeUrl(url) },
      },
      location.origin // 같은 출처로만 전달 ("*" 사용 안 함)
    );
  }

  function inspectPayload(raw, url) {
    try {
      let json = raw;
      if (typeof raw === "string") {
        if (!QUICK_RE.test(raw)) return; // 해당 없는 응답은 파싱조차 하지 않음
        json = origParse(raw);
      }
      if (!json || typeof json !== "object") return;
      emit(extractPureSpec(json), url);
    } catch (e) {
      if (DEBUG) console.warn("[트릭컬 연동기] 오류", e);
    }
  }

  // ---- fetch: 응답을 복제(clone)해서 읽기만 한다. 원본 응답/요청은 건드리지 않음 ----
  const origFetch = window.fetch;
  window.fetch = async function (...args) {
    const res = await origFetch.apply(this, args);
    try {
      const url = args[0] instanceof Request ? args[0].url : String(args[0] || "");
      res.clone().text().then((txt) => inspectPayload(txt, url)).catch(() => {});
    } catch (e) {}
    return res;
  };

  // ---- XHR: load 이벤트에서 응답만 읽는다 ----
  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._syncUrl = String(url || "");
    return origOpen.call(this, method, url, ...rest);
  };
  XMLHttpRequest.prototype.send = function (...args) {
    this.addEventListener("load", function () {
      try {
        const t = this.responseType;
        if (t === "" || t === "text") inspectPayload(this.responseText, this._syncUrl);
        else if (t === "json") inspectPayload(this.response, this._syncUrl);
        else if (t === "arraybuffer" && this.response) inspectPayload(new TextDecoder().decode(this.response), this._syncUrl);
        else if (t === "blob" && this.response) this.response.text().then((txt) => inspectPayload(txt, this._syncUrl)).catch(() => {});
      } catch (e) {}
    });
    return origSend.apply(this, args);
  };
})();
