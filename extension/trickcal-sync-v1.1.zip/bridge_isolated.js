// 트릭컬 연동기 - 확장 프로그램(ISOLATED) 브릿지
// - 트릭컬노트: 후크가 보낸 카드/사도 정보를 검증 후 chrome.storage.local 에 저장
// - 계산기 페이지: 저장된 정보를 같은 페이지로 전달
// 외부 서버로 어떤 데이터도 보내지 않는다.
(function () {
  "use strict";

  const IS_NOTE = location.hostname === "note.trickcal.com";
  const IS_CALC = location.hostname === "antarctichare.github.io";

  const isInt = (x) => Number.isInteger(x);
  const inRange = (x, min, max) => isInt(x) && x >= min && x <= max;
  const ID_KEY = /^\d{1,8}$/; // "__proto__" 같은 키가 들어오지 못하도록 숫자 키만 허용

  // 페이지 스크립트가 보낸 메시지는 신뢰하지 않는다 → 형식/범위가 맞는 값만 통과
  function sanitize(p) {
    if (!p || typeof p !== "object") return null;
    const out = { cards: {}, cardsDetail: {}, apostles: {} };

    let n = 0;
    for (const k of Object.keys(p.cards || {})) {
      if (++n > 1000) break;
      const id = Number(k), lv = p.cards[k];
      if (ID_KEY.test(k) && inRange(id, 2100000, 2299999) && inRange(lv, 1, 100)) out.cards[id] = lv;
    }

    n = 0;
    for (const k of Object.keys(p.cardsDetail || {})) {
      if (++n > 1000) break;
      const id = Number(k), d = p.cardsDetail[k];
      if (!ID_KEY.test(k) || !inRange(id, 2100000, 2299999) || !d) continue;
      if (inRange(d.level, 1, 100) && inRange(d.count, 0, 1e7) && inRange(d.limitBreak, 0, 100) && inRange(d.type, 0, 99)) {
        out.cardsDetail[id] = { level: d.level, count: d.count, limitBreak: d.limitBreak, type: d.type };
      }
    }

    n = 0;
    for (const k of Object.keys(p.apostles || {})) {
      if (++n > 500) break;
      const id = Number(k), a = p.apostles[k];
      if (!ID_KEY.test(k) || !inRange(id, 10001, 19999) || !a) continue;
      const f = ["level", "rank", "grade", "asideGrade", "activeSkillLevel", "ultimateSkillLevel", "asideLevelLimitBreak"];
      if (!f.every((x) => inRange(a[x], 0, 1000))) continue;
      out.apostles[id] = {};
      f.forEach((x) => (out.apostles[id][x] = a[x]));
    }

    if (!Object.keys(out.cards).length && !Object.keys(out.apostles).length) return null;
    return out;
  }

  window.addEventListener("message", (e) => {
    if (e.source !== window || e.origin !== location.origin || !e.data) return;

    // 트릭컬노트 → 저장
    if (IS_NOTE && e.data.type === "TRICKCAL_SPEC_CAPTURED") {
      const incoming = sanitize(e.data.payload);
      if (!incoming) return;
      chrome.storage.local.get(["trickcalSyncData"], (res) => {
        const prev = (res && res.trickcalSyncData) || {};
        const merged = {
          cards: Object.assign({}, prev.cards, incoming.cards),
          cardsDetail: Object.assign({}, prev.cardsDetail, incoming.cardsDetail),
          apostles: Object.assign({}, prev.apostles, incoming.apostles),
          timestamp: Date.now(),
        };
        chrome.storage.local.set({ trickcalSyncData: merged }, () => {
          console.log("[트릭컬 연동기] 저장 완료 → 카드", Object.keys(merged.cards).length, "/ 사도", Object.keys(merged.apostles).length);
        });
      });
      return;
    }

    // 계산기 페이지 → 요청에 응답 (트릭컬노트에서는 응답하지 않음)
    if (IS_CALC && e.data.type === "REQUEST_TRICKCAL_SYNC") {
      chrome.storage.local.get(["trickcalSyncData"], (res) => {
        if (res && res.trickcalSyncData) {
          window.postMessage({ type: "APPLY_TRICKCAL_SYNC", payload: res.trickcalSyncData }, location.origin);
        } else {
          window.postMessage({ type: "EMPTY_TRICKCAL_SYNC" }, location.origin);
        }
      });
      return;
    }

    // 계산기 페이지 → 저장 데이터 삭제 요청
    if (IS_CALC && e.data.type === "CLEAR_TRICKCAL_SYNC") {
      chrome.storage.local.remove("trickcalSyncData");
    }
  });

  // 계산기 페이지를 열면 저장된 데이터를 자동 주입
  if (IS_CALC && document.getElementById("loadoutGrid")) {
    chrome.storage.local.get(["trickcalSyncData"], (res) => {
      if (res && res.trickcalSyncData) {
        window.postMessage({ type: "APPLY_TRICKCAL_SYNC", payload: res.trickcalSyncData, auto: true }, location.origin);
      }
    });
  }
})();
